package com.niit.Daosample;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;
import org.springframework.test.context.junit4.SpringRunner;

import com.niit.Daosample.config.ConfigBook;
import com.niit.Daosample.model.Book;
import com.niit.Daosample.service.Bookserve;

@RunWith(SpringRunner.class)
@SpringJUnitConfig(classes=ConfigBook.class) 

public class testBookProj {

	@Autowired
	private Bookserve bkserve;
	
	Book book;
	@Before
	public void setUp() throws Exception 
	{
		book=new Book();
	}

	@After
	public void tearDown() throws Exception 
	{
		
	}

	@Test
	public void Adddata() 
	{
		book.setBookid(700);
		book.setBookname("java");
		book.setAuthor("Jhon");
	assertEquals("Success",true,bkserve.addServe(book));
	}
	
	@Test
	public void deletecheck()
	{
		assertEquals("not found",true,bkserve.deleteServe(700));
	}

}
