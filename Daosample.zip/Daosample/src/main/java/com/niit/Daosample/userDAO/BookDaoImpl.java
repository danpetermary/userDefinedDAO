package com.niit.Daosample.userDAO;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.Daosample.model.Book;

@Repository("bookdao")
@Transactional

public class BookDaoImpl implements BookDao 
{
	@Autowired
    private SessionFactory sessionFact;
	
	public boolean addBook(Book bk) {
		
		sessionFact.getCurrentSession().save(bk);
		return true;
	}

	public boolean deleteBook(int bookid) 
	{
		
		Book book=getBookbyId(bookid);
		if(book!=null)
		{
			sessionFact.getCurrentSession().delete(book);
				return true;
		}
		else
			return false;
	}

	public Book getBookbyId (int bookid) 
	{
	//	Book m=new Book();
		//try
		//{
				return (Book) sessionFact.getCurrentSession().createQuery("from Book where bookid="+bookid).uniqueResult();
		//}
		//catch(Exception e)
		//{
			//return m;
		//} 
	}
	

}
