package com.niit.Daosample.service;

import com.niit.Daosample.model.Book;

public interface Bookserve 
{
  public boolean addServe(Book book);
  public boolean deleteServe(int id);
 	
	
}
