package com.niit.Daosample.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niit.Daosample.model.Book;
import com.niit.Daosample.userDAO.BookDao;

@Service

public class Bookserveimpl implements Bookserve 
{
	@Autowired
	private BookDao bookdao;

	public boolean addServe(Book book) 
	{
	return (bookdao.addBook(book));	
		
	}

	public boolean deleteServe(int id) {
		
		return (bookdao.deleteBook(id));
	}

}
