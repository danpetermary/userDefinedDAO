package com.niit.Daosample.userDAO;

import com.niit.Daosample.model.Book;

public interface BookDao
{

	public boolean addBook(Book bk);
	public boolean deleteBook(int bookid);
	public Book getBookbyId(int bookid);
	
}
